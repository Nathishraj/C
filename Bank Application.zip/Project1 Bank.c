#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/stat.h>
#include<sys/types.h>
    int op;
    int bal;
    char username[30];
int reg(){
    printf("REGISTRATION PROCESS:\n");
    printf("Enter your name:\n");
    scanf("%s",&username);

    char *foldername=username;
    char filename[200];
    mkdir(foldername);
    sprintf(filename,"F:\\C Programming\\Projects\\%s",username);
    chdir(username);

    char mob[10];
    char pass[30];
    char dob[20];
    char add[50];
    char mail[20];

    printf("Enter your mobile number:\n");
    scanf("%s",&mob);
    printf("Enter your Password:\n");
    scanf("%s",&pass);
    printf("Enter your Date of Birth:\n(DD/MM/YYYY)\n");
    scanf("%s",&dob);
    printf("Enter your District:\n");
    scanf("%s",&add);
    printf("Enter your Email Id:\n");
    scanf("%s",&mail);
    printf("Enter your Initial Bal:\n");
    scanf("%d",&bal);

 FILE *fm;
 fm=fopen("mobno.txt","w");
 fprintf(fm,"%s",mob);
 fclose(fm);

 FILE *fp;
 fp=fopen("pass.txt","w");
 fprintf(fp,"%s",pass);
 fclose(fp);

 FILE *fb;
 fb=fopen("balance.txt","w");
 fprintf(fb,"%d",bal);
 fclose(fb);

 FILE *fa;
 fa=fopen("allfiles.txt","w");
 fprintf(fa,"%s\n %s\n %s\n %s\n",username,dob,add,mail);
 fclose(fa);
    }

int credit(){
    int cb;
    printf("Enter The amount to be credited..:\n");
    scanf("%d",&cb);
  if(cb<0){
    printf("Enter the Proper amount:\n");
    credit();
  }else{
    bal+=cb;
    printf("Now Your Current balance is..: %d\n",bal);
  }
show();
}

int debit(){
    int db;
    printf("Enter the amount to be debited..:\n");
    scanf("%d",&db);
    if(bal>db){
        bal-=db;
        printf("Now Your balance is..:%d\n",bal);
    }else{
        printf("Insufficient Balance\nEnter the proper amnt\n");
        debit();
    }
    show();
    }

int enq(){
    char upw[20];
    printf("Enter the password:\n");
    scanf("%s",&upw);

    chdir(username);

    char pw[20];
    FILE *fx;
    fx=fopen("pass.txt","r");
    fscanf(fx,"%s",pw);
    fclose(fx);

    if((strcmp(upw,pw))==0){
    printf("%d is Your Balance\n",bal);
    show();
    }else{
    printf("Please Enter the correct password:\n");
    enq();
    }
}

int login(){
    char mob2[70];
    char pass2[10];
    printf("Mobile number:\n");
    scanf("%s",&mob2);
    printf("Password: \n");
    scanf("%s",&pass2);

    chdir(username);

    char mob1[60];
    char pass1[20];
   FILE *fm;
   fm=fopen("mobno.txt","r");
   fscanf(fm,"%s",mob1);
   fclose(fm);

   FILE *fp;
   fp=fopen("pass.txt","r");
   fscanf(fp,"%s",pass1);
   fclose(fp);

   if(((strcmp(mob1,mob2))&&(strcmp(pass1,pass2)))==0){
      show();
   }
   else{
    printf("\nIncorrect mobile number or password!\n");
   }
 }

 int show(){
      int t;
      printf("Do you want to continue the process..?\n 1.Yes\n 2.No\n");
      scanf("%d",&t);
if(t==1){
      printf("\n Choose Your Option:\n 1.Credit\n 2.Debit\n 3.Balance Enquiry\n 4.Exit\n");
      int abc;
      scanf("%d",&abc);
      switch(abc){
    case 1:
        credit();
        break;
    case 2:
        debit();
        break;
    case 3:
        enq();
        break;
    case 4:
        printf("THANKING YOU!!");
        break;
    }
    }
else{
    printf("OK., Nice to meet you..!");
    }
}

int main(){
reg();
printf("Do you want to continue for the login page?\n 1.Yes\n 2.No\n");
        scanf("%d",&op);
        if(op==1){
             login();
        }
        else{
                printf("ThankYou!");
        }

}
